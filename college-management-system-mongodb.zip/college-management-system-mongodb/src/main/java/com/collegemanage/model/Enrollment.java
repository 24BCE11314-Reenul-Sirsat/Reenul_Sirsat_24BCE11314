package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;


@Document(collection = "enrollments")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Enrollment {

    @Id
    private String id;

    @Field("studentId")
    private String studentId;

    @Field("studentName")
    private String studentName;

    @Field("rollNumber")
    private String rollNumber;

    @Field("courseId")
    private String courseId;

    @Field("courseName")
    private String courseName;

    @Field("courseCode")
    private String courseCode;

    @Field("semester")
    private int semester;

    @Field("enrollmentDate")
    private LocalDateTime enrollmentDate;

    @Field("status")
    private String status; 
}
