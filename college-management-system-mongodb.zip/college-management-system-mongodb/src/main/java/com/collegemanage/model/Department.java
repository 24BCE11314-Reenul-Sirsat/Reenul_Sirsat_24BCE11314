package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;
@Document(collection = "departments")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Department {

    @Id
    private String id;

    @Indexed(unique = true)
    @Field("name")
    private String name;

    @Indexed(unique = true)
    @Field("code")
    private String code; 

    @Field("hodName")
    private String hodName;

    @Field("totalSeats")
    private int totalSeats;

    @Field("createdAt")
    private LocalDateTime createdAt;
}
