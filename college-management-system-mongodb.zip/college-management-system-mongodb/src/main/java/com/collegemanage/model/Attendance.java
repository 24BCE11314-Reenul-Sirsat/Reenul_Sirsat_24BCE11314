package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

@Document(collection = "attendance")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Attendance {

    @Id
    private String id;

    @Field("studentId")
    private String studentId;

    @Field("studentName")
    private String studentName;

    @Field("courseId")
    private String courseId;

    @Field("courseName")
    private String courseName;

    @Field("date")
    private String date; 
    @Field("status")
    private String status; 
    @Field("markedBy")
    private String markedBy; 
    private LocalDateTime createdAt;
}
