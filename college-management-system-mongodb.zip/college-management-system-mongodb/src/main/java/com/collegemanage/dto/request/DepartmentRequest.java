package com.college.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class DepartmentRequest {

    @NotBlank(message = "Department name is required")
    private String name;

    @NotBlank(message = "Department code is required")
    private String code; // e.g. "CSE", "ECE"

    @NotBlank(message = "HOD name is required")
    private String hodName;

    @Positive(message = "Total seats must be a positive number")
    private int totalSeats;
}
