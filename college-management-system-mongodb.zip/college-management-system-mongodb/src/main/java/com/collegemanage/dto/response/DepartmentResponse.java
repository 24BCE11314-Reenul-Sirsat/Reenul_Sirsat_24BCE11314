package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentResponse {

    private String id;
    private String name;
    private String code;
    private String hodName;
    private int totalSeats;
    private LocalDateTime createdAt;
}
