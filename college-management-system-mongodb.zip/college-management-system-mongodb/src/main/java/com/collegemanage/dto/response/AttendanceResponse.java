package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceResponse {

    private String id;
    private String studentId;
    private String studentName;
    private String courseId;
    private String courseName;
    private String date;
    private String status;
    private String markedBy;
    private LocalDateTime createdAt;
}
