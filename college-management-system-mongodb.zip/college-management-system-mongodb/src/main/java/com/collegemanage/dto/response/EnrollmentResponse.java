package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentResponse {

    private String id;
    private String studentId;
    private String studentName;
    private String rollNumber;
    private String courseId;
    private String courseName;
    private String courseCode;
    private int semester;
    private LocalDateTime enrollmentDate;
    private String status;
}
