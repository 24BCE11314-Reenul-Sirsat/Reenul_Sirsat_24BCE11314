package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentResponse {

    private String id;
    private String name;
    private String email;
    private String phone;
    private String rollNumber;
    private String departmentId;
    private String departmentName;
    private int semester;
    private String batch;
    private String gender;
    private String dateOfBirth;
    private String address;
    private boolean isActive;
    private LocalDateTime createdAt;
}
