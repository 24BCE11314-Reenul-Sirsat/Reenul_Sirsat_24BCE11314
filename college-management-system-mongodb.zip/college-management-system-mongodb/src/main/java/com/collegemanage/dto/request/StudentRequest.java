package com.college.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class StudentRequest {

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone is required")
    private String phone;

    @NotBlank(message = "Department ID is required")
    private String departmentId;

    @Min(value = 1, message = "Semester must be between 1 and 8")
    @Max(value = 8, message = "Semester must be between 1 and 8")
    private int semester;

    @NotBlank(message = "Batch is required")
    private String batch; // e.g. "2023-2027"

    @NotBlank(message = "Gender is required")
    private String gender;

    private String dateOfBirth;

    private String address;
}
