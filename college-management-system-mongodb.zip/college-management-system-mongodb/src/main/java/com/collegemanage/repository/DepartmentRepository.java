package com.college.repository;

import com.college.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DepartmentRepository extends MongoRepository<Department, String> {

    boolean existsByName(String name);

    boolean existsByCode(String code);

    Optional<Department> findByCode(String code);
}
