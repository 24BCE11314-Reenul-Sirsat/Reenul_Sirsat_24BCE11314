package com.college.repository;

import com.college.model.Attendance;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttendanceRepository extends MongoRepository<Attendance, String> {

    List<Attendance> findByCourseId(String courseId);

    List<Attendance> findByStudentId(String studentId);

    List<Attendance> findByCourseIdAndDate(String courseId, String date);

    List<Attendance> findByStudentIdAndCourseId(String studentId, String courseId);

    long countByStudentIdAndCourseId(String studentId, String courseId);

    long countByStudentIdAndCourseIdAndStatusIn(String studentId, String courseId, List<String> statuses);
}
