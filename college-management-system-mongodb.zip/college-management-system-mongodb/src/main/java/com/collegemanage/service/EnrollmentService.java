package com.college.service;

import com.college.dto.request.EnrollmentRequest;
import com.college.dto.response.EnrollmentResponse;
import com.college.exception.ResourceNotFoundException;
import com.college.exception.ValidationException;
import com.college.model.Course;
import com.college.model.Enrollment;
import com.college.model.Student;
import com.college.repository.CourseRepository;
import com.college.repository.EnrollmentRepository;
import com.college.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EnrollmentService {

    @Autowired private EnrollmentRepository enrollmentRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;

    public EnrollmentResponse enroll(EnrollmentRequest request) {
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student", "id", request.getStudentId()));
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course", "id", request.getCourseId()));

        if (enrollmentRepository.existsByStudentIdAndCourseIdAndStatus(
                student.getId(), course.getId(), "ENROLLED")) {
            throw new ValidationException("Student is already enrolled in this course.");
        }

        if (course.getEnrolledStudents() >= course.getMaxStudents()) {
            throw new ValidationException(
                    "Course '" + course.getName() + "' is full. No available seats.");
        }

        Enrollment enrollment = Enrollment.builder()
                .studentId(student.getId())
                .studentName(student.getName())
                .rollNumber(student.getRollNumber())
                .courseId(course.getId())
                .courseName(course.getName())
                .courseCode(course.getCourseCode())
                .semester(course.getSemester())
                .enrollmentDate(LocalDateTime.now())
                .status("ENROLLED")
                .build();

        enrollmentRepository.save(enrollment);

        course.setEnrolledStudents(course.getEnrolledStudents() + 1);
        courseRepository.save(course);

        return toResponse(enrollment);
    }

    public List<EnrollmentResponse> getAll() {
        return enrollmentRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EnrollmentResponse> getByStudent(String studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EnrollmentResponse> getByCourse(String courseId) {
        return enrollmentRepository.findByCourseId(courseId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public EnrollmentResponse drop(String id) {
        Enrollment enrollment = findOrThrow(id);
        if (!"ENROLLED".equals(enrollment.getStatus())) {
            throw new ValidationException("Only ENROLLED enrollments can be dropped.");
        }
        enrollment.setStatus("DROPPED");
        enrollmentRepository.save(enrollment);

        // Decrement course count
        courseRepository.findById(enrollment.getCourseId()).ifPresent(course -> {
            course.setEnrolledStudents(Math.max(0, course.getEnrolledStudents() - 1));
            courseRepository.save(course);
        });

        return toResponse(enrollment);
    }

    /** Mark enrollment as COMPLETED */
    public EnrollmentResponse complete(String id) {
        Enrollment enrollment = findOrThrow(id);
        if (!"ENROLLED".equals(enrollment.getStatus())) {
            throw new ValidationException("Only ENROLLED enrollments can be completed.");
        }
        enrollment.setStatus("COMPLETED");
        return toResponse(enrollmentRepository.save(enrollment));
    }

    private Enrollment findOrThrow(String id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment", "id", id));
    }

    private EnrollmentResponse toResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .id(e.getId())
                .studentId(e.getStudentId())
                .studentName(e.getStudentName())
                .rollNumber(e.getRollNumber())
                .courseId(e.getCourseId())
                .courseName(e.getCourseName())
                .courseCode(e.getCourseCode())
                .semester(e.getSemester())
                .enrollmentDate(e.getEnrollmentDate())
                .status(e.getStatus())
                .build();
    }
}
