package com.college.cms.service;

import com.college.cms.model.Student;
import com.college.cms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student addStudent(Student student) {
        return studentRepository.save(student);
    }
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    public Optional<Student> getStudentById(String id) {
        return studentRepository.findById(id);
    }
    public Optional<Student> getStudentByEnrollmentNumber(String enrollmentNumber) {
        return studentRepository.findByEnrollmentNumber(enrollmentNumber);
    }
    public List<Student> getStudentsByDepartment(String departmentId) {
        return studentRepository.findByDepartmentId(departmentId);
    }
    public List<Student> getStudentsByCourse(String course) {
        return studentRepository.findByCourse(course);
    }

    public Student updateStudent(String id, Student updatedStudent) {
        Optional<Student> existing = studentRepository.findById(id);
        if (existing.isPresent()) {
            updatedStudent.setId(id);
            return studentRepository.save(updatedStudent);
        }
        throw new RuntimeException("Student not found with id: " + id);
    }

    public String deleteStudent(String id) {
        if (studentRepository.existsById(id)) {
            studentRepository.deleteById(id);
            return "Student deleted successfully with id: " + id;
        }
        throw new RuntimeException("Student not found with id: " + id);
    }
}
