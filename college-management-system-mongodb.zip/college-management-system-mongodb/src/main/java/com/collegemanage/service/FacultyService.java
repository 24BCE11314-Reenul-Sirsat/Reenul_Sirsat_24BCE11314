package com.college.service;

import com.college.dto.request.FacultyRequest;
import com.college.dto.response.FacultyResponse;
import com.college.exception.DuplicateResourceException;
import com.college.exception.ResourceNotFoundException;
import com.college.model.Department;
import com.college.model.Faculty;
import com.college.repository.DepartmentRepository;
import com.college.repository.FacultyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.Year;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FacultyService {

    @Autowired private FacultyRepository facultyRepository;
    @Autowired private DepartmentRepository departmentRepository;

    public FacultyResponse create(FacultyRequest request) {
        if (facultyRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Faculty", "email", request.getEmail());
        }
        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));

        String employeeId = generateEmployeeId();
        Faculty faculty = Faculty.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .employeeId(employeeId)
                .departmentId(dept.getId())
                .departmentName(dept.getName())
                .designation(request.getDesignation())
                .qualification(request.getQualification())
                .experience(request.getExperience())
                .isActive(true)
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(facultyRepository.save(faculty));
    }

    private String generateEmployeeId() {
        int year = Year.now().getValue();
        String prefix = "FAC-" + year + "-";
        long count = facultyRepository.countByEmployeeIdStartingWith(prefix);
        return prefix + String.format("%03d", count + 1);
    }

    public List<FacultyResponse> getAll() {
        return facultyRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public FacultyResponse getById(String id) {
        return toResponse(findOrThrow(id));
    }

    public List<FacultyResponse> getByDepartment(String departmentId) {
        return facultyRepository.findByDepartmentId(departmentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public FacultyResponse update(String id, FacultyRequest request) {
        Faculty faculty = findOrThrow(id);
        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));

        faculty.setName(request.getName());
        faculty.setPhone(request.getPhone());
        faculty.setDepartmentId(dept.getId());
        faculty.setDepartmentName(dept.getName());
        faculty.setDesignation(request.getDesignation());
        faculty.setQualification(request.getQualification());
        faculty.setExperience(request.getExperience());

        return toResponse(facultyRepository.save(faculty));
    }

    public void deactivate(String id) {
        Faculty faculty = findOrThrow(id);
        faculty.setActive(false);
        facultyRepository.save(faculty);
    }

    private Faculty findOrThrow(String id) {
        return facultyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Faculty", "id", id));
    }

    private FacultyResponse toResponse(Faculty f) {
        return FacultyResponse.builder()
                .id(f.getId())
                .name(f.getName())
                .email(f.getEmail())
                .phone(f.getPhone())
                .employeeId(f.getEmployeeId())
                .departmentId(f.getDepartmentId())
                .departmentName(f.getDepartmentName())
                .designation(f.getDesignation())
                .qualification(f.getQualification())
                .experience(f.getExperience())
                .isActive(f.isActive())
                .createdAt(f.getCreatedAt())
                .build();
    }
}
