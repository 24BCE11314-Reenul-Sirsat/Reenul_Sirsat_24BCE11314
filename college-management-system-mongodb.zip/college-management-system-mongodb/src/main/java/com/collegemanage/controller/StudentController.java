package com.college.controller;

import com.college.dto.request.StudentRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.StudentResponse;
import com.college.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping
    public ResponseEntity<ApiResponse<StudentResponse>> create(
            @Valid @RequestBody StudentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Student added successfully",
                        studentService.create(request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<Page<StudentResponse>>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success("Students fetched",
                studentService.getAll(page, size)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<StudentResponse>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Student found",
                studentService.getById(id)));
    }

    /** GET /api/students/department/{departmentId} */
    @GetMapping("/department/{departmentId}")
    public ResponseEntity<ApiResponse<List<StudentResponse>>> getByDepartment(
            @PathVariable String departmentId) {
        return ResponseEntity.ok(ApiResponse.success("Students fetched",
                studentService.getByDepartment(departmentId)));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<StudentResponse>>> search(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String rollNumber) {
        return ResponseEntity.ok(ApiResponse.success("Search results",
                studentService.search(name, rollNumber)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<StudentResponse>> update(
            @PathVariable String id,
            @Valid @RequestBody StudentRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Student updated",
                studentService.update(id, request)));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deactivate(@PathVariable String id) {
        studentService.deactivate(id);
        return ResponseEntity.ok(ApiResponse.success("Student deactivated", null));
    }
}
