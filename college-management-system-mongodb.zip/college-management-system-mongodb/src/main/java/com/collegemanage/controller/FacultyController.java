package com.college.controller;

import com.college.dto.request.FacultyRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.FacultyResponse;
import com.college.service.FacultyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/faculty")
public class FacultyController {

    @Autowired
    private FacultyService facultyService;

    @PostMapping
    public ResponseEntity<ApiResponse<FacultyResponse>> create(
            @Valid @RequestBody FacultyRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Faculty added successfully",
                        facultyService.create(request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<FacultyResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Faculty list fetched",
                facultyService.getAll()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<FacultyResponse>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Faculty found",
                facultyService.getById(id)));
    }

    @GetMapping("/department/{departmentId}")
    public ResponseEntity<ApiResponse<List<FacultyResponse>>> getByDepartment(
            @PathVariable String departmentId) {
        return ResponseEntity.ok(ApiResponse.success("Faculty fetched",
                facultyService.getByDepartment(departmentId)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<FacultyResponse>> update(
            @PathVariable String id,
            @Valid @RequestBody FacultyRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Faculty updated",
                facultyService.update(id, request)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deactivate(@PathVariable String id) {
        facultyService.deactivate(id);
        return ResponseEntity.ok(ApiResponse.success("Faculty deactivated", null));
    }
}
